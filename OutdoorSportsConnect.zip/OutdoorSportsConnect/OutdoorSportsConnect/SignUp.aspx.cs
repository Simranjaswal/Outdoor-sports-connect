﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Globalization;
using System.Data;
using System.Web.UI.HtmlControls;

public partial class SignUp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            list_dob_month.Items.Clear();
            list_dob_month.Items.Add(new ListItem("-Birth Month-", ""));
            for (int i = 1; i <= 12; i++)
            {
                DateTime d = new DateTime(2018, i, 1);
                list_dob_month.Items.Add(new ListItem(d.ToString("MMMM"), i.ToString()));
            }

            list_dob_year.Items.Clear();
            list_dob_year.Items.Add(new ListItem("-Birth Year-", ""));
            for (int i = 2018; i >= 1918; i--)
            {
                list_dob_year.Items.Add(new ListItem(i.ToString(), i.ToString()));
            }

            list_dob_day.Items.Clear();
            list_dob_day.Items.Add(new ListItem("-Birth Day-", ""));
            for (int i = 1; i <= 31; i++)
            {
                list_dob_day.Items.Add(new ListItem(i.ToString(), i.ToString()));
            }
            
        }
    }


    protected void btn_sign_up_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString);
            SqlDataReader reader;
            SqlCommand cmd;
            conn.Open();
            string Query = "SELECT Email FROM [Users] WHERE Email = @Email";
            cmd = new SqlCommand(Query, conn);
            cmd.Parameters.AddWithValue("@Email", txt_email.Value);
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                string email = reader.GetValue(0).ToString();
                reader.Close();
                throw new Exception("Email already exists");
            } else {
                reader.Close();
                cmd.Dispose();
                DateTime dob = new DateTime(Int32.Parse(list_dob_year.SelectedItem.Value), Int32.Parse(list_dob_month.SelectedItem.Value), Int32.Parse(list_dob_day.SelectedItem.Value));

                Query = "INSERT INTO [Users] (First_Name, Last_Name, Email, Mobile, DOB, Gender, Password) VALUES (@First_Name, @Last_Name, @Email, @Mobile, @DOB, @Gender, @Password)";
                cmd = new SqlCommand(Query, conn);
                cmd.Parameters.AddWithValue("@First_Name", txt_first_name.Value);
                cmd.Parameters.AddWithValue("@Last_Name", txt_last_name.Value);
                cmd.Parameters.AddWithValue("@Email", txt_email.Value);
                cmd.Parameters.AddWithValue("@Mobile", txt_mobile.Value);
                cmd.Parameters.AddWithValue("@DOB", dob.ToString("dd-MMM-yyyy"));
                cmd.Parameters.AddWithValue("@Gender", List_Gender.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@Password", txt_password.Value);
                cmd.ExecuteNonQuery();
                HtmlControl control = FindControl("error_msg") as HtmlControl;
                control.Attributes["class"] = "alert alert-success";
                error_msg.InnerHtml = "You have registered successfully, You can login now";
                form_container.InnerHtml = "";
            }
            cmd.Dispose();
            conn.Close();
         }
        catch (SqlException ex)
        {
            HtmlControl control = FindControl("error_msg") as HtmlControl;
            control.Attributes["class"] = "alert alert-danger";
            error_msg.InnerHtml = "Sql Error : " + ex.Message.ToString();
        }
        catch (Exception ex)
        {
            HtmlControl control = FindControl("error_msg") as HtmlControl;
            control.Attributes["class"] = "alert alert-danger";
            error_msg.InnerHtml = ex.Message.ToString();
        }
    }
}